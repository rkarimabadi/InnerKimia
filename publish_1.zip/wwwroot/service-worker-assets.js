self.assetsManifest = {
  "version": "0RFEB7M9",
  "assets": [
    {
      "hash": "sha256-aOqZDHC9QlFa1cLLopJ/WlZpmBRChxB3bQDzWUDWAM0=",
      "url": "_framework/InnerKimia.Application.02qiqnkpol.wasm"
    },
    {
      "hash": "sha256-JcpDSD6k2pYQ4qM4MJ57p0BrGQpIt+1Zk+qyAxIMudE=",
      "url": "_framework/InnerKimia.Domain.danxark4mc.wasm"
    },
    {
      "hash": "sha256-dH/mbYXNpxPqrRE85jZrjyEhpig/2y/ruuMX6Ko7ARw=",
      "url": "_framework/InnerKimia.Infrastructure.kijznvyrw6.wasm"
    },
    {
      "hash": "sha256-uSQ+i0CTVqhiyRVM8+KXXDG3IOjI5wGbJahU9g5cdAU=",
      "url": "_framework/InnerKimia.WebAssembly.dzwbp0bt2w.wasm"
    },
    {
      "hash": "sha256-bkRfJw0dn/Zy29h3cN061NqZXdGgG/GOb6oRiqImWPI=",
      "url": "_framework/Microsoft.AspNetCore.Components.6ml8xtd07z.wasm"
    },
    {
      "hash": "sha256-9VGt9/R7rmypZuO8apV7eRLgY+4m3VNkJ40q13T4MyU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.r0jb1q3o1y.wasm"
    },
    {
      "hash": "sha256-jB/Gf1i7eXuQqAzqY/ZONe+hrW3x94pYZlL+G0Cv7Co=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.0prlth0hc4.wasm"
    },
    {
      "hash": "sha256-V/8lrAHQfJYsJtV+bKRHL6fmMFhJhAOyoTNfGTbwTdQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.7sm4vp77d1.wasm"
    },
    {
      "hash": "sha256-M/V9DIZ9otM7/qEt+xn3wagkoRiLOf4JMPyDoo6WUM8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.n3roazub70.wasm"
    },
    {
      "hash": "sha256-XQykit2HYxnB0emmOc5bra6XuZq3KgCfazi8kFAErDs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jgtmx19396.wasm"
    },
    {
      "hash": "sha256-ojHYpodaJYEe1Ux6GuDOmGTVigsFn6l4xRY9X9igwB0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.i8fudnimwy.wasm"
    },
    {
      "hash": "sha256-wPj/fOeoE7JKOgIYh6OIvl/k3Iw6EPDmmXDjtnQ6rJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g0r86u4i0h.wasm"
    },
    {
      "hash": "sha256-iH/ulRtfhtNcqTHnWZyfhbmQCnzZZE06GgEWyo7ynV4=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.cn0xeccr7p.wasm"
    },
    {
      "hash": "sha256-5E3YJsqbWNbv+OJiZ1kCoV5czf1fXeUBZBKig0eHQKs=",
      "url": "_framework/Microsoft.Extensions.Logging.km3zhtnk76.wasm"
    },
    {
      "hash": "sha256-2xzw4xsXcqL7SQ6R76v+GZrC7ZqwjD2SQaJrbh6IFlc=",
      "url": "_framework/Microsoft.Extensions.Options.xtnmlnlmnd.wasm"
    },
    {
      "hash": "sha256-+HoDX+e0bGwi8OjZvR5ZpN4OxMMBE8OX4f2wu++wdqE=",
      "url": "_framework/Microsoft.Extensions.Primitives.geznw6vy35.wasm"
    },
    {
      "hash": "sha256-hbzWuXrlepIqY/y+nQ2ZAFer2/njy1dc+Y4LUaAaL5E=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p386u0jty9.wasm"
    },
    {
      "hash": "sha256-j93883TLWrUsylBnXBVb1aCW34uImOVFvkmgV7v8tx0=",
      "url": "_framework/Microsoft.JSInterop.bdr89uoxtd.wasm"
    },
    {
      "hash": "sha256-JD8RtIyhSYUx4zpYwAX8hQvk+alDHKvObxLOIyw53mY=",
      "url": "_framework/System.Collections.05rnmw0w00.wasm"
    },
    {
      "hash": "sha256-HbMhvXwNC4SAV7tiueIutWTgvFDf5jRLQtmU5mVZIc8=",
      "url": "_framework/System.Collections.Concurrent.rexjxb5czh.wasm"
    },
    {
      "hash": "sha256-TutBFnN16KZ5dB7V7uXSJ7ZnINFmRbMP2k8T0OggMQo=",
      "url": "_framework/System.Collections.Immutable.qxxaxk1e1o.wasm"
    },
    {
      "hash": "sha256-NQkKskUXENdTSf2C0+y41sjKi68CHmUqCgPPLNxKyGw=",
      "url": "_framework/System.ComponentModel.h9eo79o86x.wasm"
    },
    {
      "hash": "sha256-fG5C33jvnQc30BhFHHcR3muFlB4tfYRR2x1XYylDdrM=",
      "url": "_framework/System.Console.ckimbfyjuj.wasm"
    },
    {
      "hash": "sha256-V5z9/XlJMVOFEDQ+R/mfLxmcykbKzh9+yhFeRdF4kdU=",
      "url": "_framework/System.IO.Pipelines.h68d94scrb.wasm"
    },
    {
      "hash": "sha256-yxVILeWER67lP81XP+m/AMSclhU9Z+XgkE7Y+1NUd7E=",
      "url": "_framework/System.Linq.d6pj83bd6q.wasm"
    },
    {
      "hash": "sha256-SrBVMo6y8K0FW1a07/LPx+E73mNBQDIPA1+IPvft0aI=",
      "url": "_framework/System.Memory.acxyzgdz32.wasm"
    },
    {
      "hash": "sha256-JAE9AaKDVKxndwRZ1OskmjfSPR3izzJ0StYkztrZTBQ=",
      "url": "_framework/System.Net.Http.glm30nrgji.wasm"
    },
    {
      "hash": "sha256-6qfRgKqAwwmWzGgvzRHh01AJ7x6iBsgex62EJYI/owY=",
      "url": "_framework/System.Net.Primitives.64ga4lbdmv.wasm"
    },
    {
      "hash": "sha256-3t6Q4HeeCgOitwTF1hE5tzihiQx9VF7WKG6IqTOhTSg=",
      "url": "_framework/System.Private.CoreLib.6vcknzkeqo.wasm"
    },
    {
      "hash": "sha256-GKw5UglIavdJ+pv/5RP3KeP0+pUmf2KWkc3LjqO1s5o=",
      "url": "_framework/System.Private.Uri.8sqa29gs3n.wasm"
    },
    {
      "hash": "sha256-DNAHuD8D+2NBBI+EK1w/x03qITnF0Lpck8bRmZtaT5o=",
      "url": "_framework/System.Runtime.4icnp62uts.wasm"
    },
    {
      "hash": "sha256-2nWN1zwezK82JRmcnLLcKzdroP7qZRNl6DW0r2jhKe4=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.2qzse51b5r.wasm"
    },
    {
      "hash": "sha256-pdi8rUtz97K7+q5y/AgnLY20C4reLdWB+WoFACY2+qM=",
      "url": "_framework/System.Text.Encodings.Web.n5x6mx40rp.wasm"
    },
    {
      "hash": "sha256-newBUXnA8w230zHm8qDvpX49QaqYc/n3XzwTyZalE7c=",
      "url": "_framework/System.Text.Json.77604wj7xg.wasm"
    },
    {
      "hash": "sha256-SKkTQL9D0Loskr+NX705/WITcRNb/8VQlQorMrz5S6M=",
      "url": "_framework/System.Text.RegularExpressions.0e9rlv7vxy.wasm"
    },
    {
      "hash": "sha256-8VjI8D6kDSz0JIqDxCZ6ACNbPThMFdASyoZBbyx/Dbk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-RlcAz/486MXaIIFuL44+jDfmv2jx813CcGdwObzEbfk=",
      "url": "_framework/dotnet.native.2ugmiy9gdc.js"
    },
    {
      "hash": "sha256-3d+rE87f61IQdcPizsJn7Y5friWPuwRfWcbiukWgjec=",
      "url": "_framework/dotnet.native.ppo7bfy3uh.wasm"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-VQ7kl7DSpZsN1xc+97mc0km7vV3ZAwsctFHE7dFKzsg=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-sZo/9PJjzNMz5UQNqnzmyDE7/H1uaCa4/RZKtIIHUPw=",
      "url": "css/game.css"
    },
    {
      "hash": "sha256-QJX/whmm4SKlg3xJURKBCQ8yvYlqGuDyWhEOqAN4SQA=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-Black.ttf"
    },
    {
      "hash": "sha256-kuszO7QQ0oz6cLr2XygT10hlaFwHNvyXn7yOpS8ut9M=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-Bold.ttf"
    },
    {
      "hash": "sha256-a0BJzL3kUxqIODuaAHtTqIrjYSH3NPCBBbmrr9oSdnM=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-ExtraBold.ttf"
    },
    {
      "hash": "sha256-gUsF3lwMjC802XQhFO3yztrHvsQ+gxdzgBCmNxTap1A=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-ExtraLight.ttf"
    },
    {
      "hash": "sha256-N+TBQumGuK33+CyN5AGVevl8IpRkFv2f4McBOsuJO+g=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-Light.ttf"
    },
    {
      "hash": "sha256-PJ8s+Sa8vsBnmkyapyf3okgIZzIBqFCbKAyMYqTGT8k=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-Medium.ttf"
    },
    {
      "hash": "sha256-DujhbfPwrYvHlROC1Zky/KxHxDkcJ+4VJneAdow2Xek=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-Regular.ttf"
    },
    {
      "hash": "sha256-RrZSGaA0Dbj0eswujAIun9cLWsrfppvhryAENf/SbjI=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-SemiBold.ttf"
    },
    {
      "hash": "sha256-HdYcejFOHJPpdiyNKJdtIgKgNhLtXyEU9G6GOH/ug0g=",
      "url": "fonts/Peyda/01-Standard/TTF/Peyda-Thin.ttf"
    },
    {
      "hash": "sha256-2UJORbSxBSTbhEZbxqktt9frvxDO9RAZqpcBS+yDcGQ=",
      "url": "fonts/Peyda/01-Standard/WebFonts/Peyda.html"
    },
    {
      "hash": "sha256-JCWOKPU9Pp9p5XaTW+PFQXHazJePj6S7LOxcFdVPPok=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fontiran.css"
    },
    {
      "hash": "sha256-PnbMFb2tcR7EjIREE+r/XUSD3yFRsqrtaZNEi1YBUSQ=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-Black.woff"
    },
    {
      "hash": "sha256-R4P5f+RfJqmnsbg74lrVRkgNsqi/6XF+JwRy4/heCBg=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-Bold.woff"
    },
    {
      "hash": "sha256-SiuR7cESOluzWpP3TnOBeykns6S+hfCnDdn2/lbcLIA=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-ExtraBold.woff"
    },
    {
      "hash": "sha256-PrqHBX2+9X61gQ6C8x7wkAXJT6iZi+/FpB4R8V1iTis=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-ExtraLight.woff"
    },
    {
      "hash": "sha256-Zuqv9kRLem/yOIHInDnWy9lH/T5lIUZsf6LDXcS+vWs=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-Light.woff"
    },
    {
      "hash": "sha256-zthNwxHklgMmd3vTPFsyZJfW/qRuUlUEWJWLSo446wI=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-Medium.woff"
    },
    {
      "hash": "sha256-7vOu6pReh8RnX79hEp3iZ8vpSX2OuqgVDvNHc2CGA4Q=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-Regular.woff"
    },
    {
      "hash": "sha256-KMVx6Ra4Dh6ivxOgHkyqZXo/wUJqKb56IttXcmBsnfQ=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-SemiBold.woff"
    },
    {
      "hash": "sha256-89L+Loxn4HWJHf/a/+6yoxuFhAeK7LyUhc9eRhn7EWI=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff/PeydaWeb-Thin.woff"
    },
    {
      "hash": "sha256-h9OOTLBG34/XMIh968knnm1FUctzSzN9zuvY4ugKF3Q=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-Black.woff2"
    },
    {
      "hash": "sha256-1cCiIILfdornNNUl+8NuYt8wHFHTvriRna9RwFg+T/U=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-Bold.woff2"
    },
    {
      "hash": "sha256-+KXGQiP+/Crm/EUyFXBjdLcDGaLc4mPXwP8HQJkRJPs=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-ExtraBold.woff2"
    },
    {
      "hash": "sha256-A8crkwxsGLieXxm4XN5tXSTJ7LHjjwRNb9I/kNWFwdI=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-ExtraLight.woff2"
    },
    {
      "hash": "sha256-zLhous5Hl0wBPWziVgEI6sxEgYxf23aqQm8Mk6yfDrI=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-Light.woff2"
    },
    {
      "hash": "sha256-h4JDVP7wJmcT1b6Ns2s2JvGFOgsLw5855/nH76k2D2Y=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-Medium.woff2"
    },
    {
      "hash": "sha256-mpE1IrVgGtBOy/ykly4oHFg+3F1bF0+WT+Y1B5den48=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-Regular.woff2"
    },
    {
      "hash": "sha256-cyMeFA9fNJZzZcvslZd/q2Uz0lnrOVHk234hUGhExz4=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-SemiBold.woff2"
    },
    {
      "hash": "sha256-IESNcTLmrfB6tgnHLeP0I4b6xWOAKg1ZmqhP5ToYAq8=",
      "url": "fonts/Peyda/01-Standard/WebFonts/fonts/woff2/PeydaWeb-Thin.woff2"
    },
    {
      "hash": "sha256-FoQpUbRGggx6KJdQ9A7peV9PmLEBed6Pb5Be4B3jOeI=",
      "url": "fonts/Peyda/01-Standard/WebFonts/style.css"
    },
    {
      "hash": "sha256-FtzkLaooem255eeYmJHh0/FDRCW/QmoXcJE88TEqnvw=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-Black.ttf"
    },
    {
      "hash": "sha256-RqAqgKB5NP2uqBIBE0WoweuVQAR6ANaPr0pDC6lnFM8=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-Bold.ttf"
    },
    {
      "hash": "sha256-QgnW6DANmWPPu8w3Rx5VEFDEK44g59bgth5YePWyNrU=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-ExtraBold.ttf"
    },
    {
      "hash": "sha256-77mWadspwEoh1Ev2GlCeArC3CZBWSim4DkzjXrGGTpE=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-ExtraLight.ttf"
    },
    {
      "hash": "sha256-MltqbT/yhJ3BBC+GDwl0PWzsuDVBs4tYFa6r7gq57UA=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-Light.ttf"
    },
    {
      "hash": "sha256-HNcjyRFxqIFJ9G+3MZJRVwpnpnZhK0cCpQ+SoRQX9Ec=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-Medium.ttf"
    },
    {
      "hash": "sha256-JGpPfLpCmo2K0BmNOHFB3qJSYDJqEplnqYL8BTLEhUI=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-Regular.ttf"
    },
    {
      "hash": "sha256-ZC8UAhBEKZGKUsrdoN9WRWt01F1ZhRiXPfiv4MLQokM=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-SemiBold.ttf"
    },
    {
      "hash": "sha256-L0ZBI5+W/QvTDFl2O0rTnUeNCBcL7WEpzL8JVtBlT4Y=",
      "url": "fonts/Peyda/02-Farsi_Namerals/TTF/PeydaFaNum-Thin.ttf"
    },
    {
      "hash": "sha256-tzJQd3JLFMf8wTBqxgICcBppJG2tzqEIE5/zeZEuoPg=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fontiran.css"
    },
    {
      "hash": "sha256-psfh49uhKXEN9ml4DFXK4yqkx/T8Z9oqT5lzPenaQhM=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-Black.woff"
    },
    {
      "hash": "sha256-B1inQbG89eOm/ihitx6NVsnj+1igdAFRkzfGbRBIXQk=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-Bold.woff"
    },
    {
      "hash": "sha256-91ZwC9SO+30Ij4ygiloFSb3+xhaqeIwKQ37Y0nNvyGY=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-ExtraBold.woff"
    },
    {
      "hash": "sha256-v9+eFQu1ZALz/IlnytUS5GYOpYNF4RmSsJ9CTNW59C0=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-ExtraLight.woff"
    },
    {
      "hash": "sha256-vdsS+ltlBPf/ANR1TQQPUUAYZQrnh1FaPJuQjH8KX9o=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-Light.woff"
    },
    {
      "hash": "sha256-N/hkg/zbvTf4b/sNQ5Qo7VPmF91ScWaFrhehqB6OYM0=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-Medium.woff"
    },
    {
      "hash": "sha256-VX+SW32U52+wFKdtVWOHnXFUYrx+w+z3z0iJBci1h24=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-Regular.woff"
    },
    {
      "hash": "sha256-OQS7gDIc3+u4CsV3Mo/pEA+MMdN+FFzDHl59hi+s8iA=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-SemiBold.woff"
    },
    {
      "hash": "sha256-B/7m3dw95BxYpFYKp7O9VLq38v50lLMcM1A7L4SoEzs=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff/PeydaWebFaNum-Thin.woff"
    },
    {
      "hash": "sha256-1ZmraUQHHPONtqkyAM44RGGnmkcV94lrdwivezvE2jM=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-Black.woff2"
    },
    {
      "hash": "sha256-uh9FtIFNOyQrSoGr5yB/pRi7wBDEwQIXsFfKTqz9MiA=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-Bold.woff2"
    },
    {
      "hash": "sha256-MfqM4zip7Cmx8T+2BiOkKIFC4xbo4SkojfROIQ9BoTs=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-ExtraBold.woff2"
    },
    {
      "hash": "sha256-xoioOaGBPiQj0su6OhgSmm7lOir/A5l7p7yIUlHSYAc=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-ExtraLight.woff2"
    },
    {
      "hash": "sha256-m8oJDNnNj4r/R7gvpISS9yPM4AOZBHmQF8bPW+jkTcI=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-Light.woff2"
    },
    {
      "hash": "sha256-uyaj+DGWEoFBGRq9U1V6qkAq8c9BeF52O9fnBPNjc9E=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-Medium.woff2"
    },
    {
      "hash": "sha256-vN9ZRpeyulKsdY6nE56AGjL8Oh36VAfnEAvnKh7ycd4=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-Regular.woff2"
    },
    {
      "hash": "sha256-moJV5XjKyAOyN4sTFjBzbrac3FjctT3xZErcHtS1aPo=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-SemiBold.woff2"
    },
    {
      "hash": "sha256-2Hz+cAkzscXhIYY/O6i00v3OFvdlfXIhfOF6nivXi2A=",
      "url": "fonts/Peyda/02-Farsi_Namerals/WebFonts/fonts/woff2/PeydaWebFaNum-Thin.woff2"
    },
    {
      "hash": "sha256-xDK6cf6zmLWN7kI3yLfiJQ+nf/9Aj4DZI+xwpmbe+Wg=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-Black.ttf"
    },
    {
      "hash": "sha256-QcGO5tEV5gTT7U70260kW0i2B7HjcqMVkHrC5B7xqvQ=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-Bold.ttf"
    },
    {
      "hash": "sha256-FfP20WvVEY59KY399QyFRkIDpwL8+IQQuoBYHzU9lA4=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-ExtraBold.ttf"
    },
    {
      "hash": "sha256-5bYt2QaDG3DGQtsqiNluYSSIQ5A2xff/0OfMFDp9Z84=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-ExtraLight.ttf"
    },
    {
      "hash": "sha256-WsxKlJIvkBlDcbVPzToyDG4bLG21KTQkb2rZH5f5Fnc=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-Light.ttf"
    },
    {
      "hash": "sha256-2keeEaCgNlgwukGuakTmlAlUDFjCSlW3kFjEBcut8Q0=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-Medium.ttf"
    },
    {
      "hash": "sha256-LeFPutRSZCJJvxKyUNgJ9jqpO0QDXS+VbMsNHvn4bo8=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-Regular.ttf"
    },
    {
      "hash": "sha256-8PsKI3C1mcCkfWg1kvBohIQLbxGyrEwyqrVx6ThhjN0=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-SemiBold.ttf"
    },
    {
      "hash": "sha256-JqRVhCn4fb2gCWLkO1YiVX06S83CFxLmgTpAoJh19Z8=",
      "url": "fonts/Peyda/03- Non English/TTF/PeydaNoEn-Thin.ttf"
    },
    {
      "hash": "sha256-7obNL2j/X7+3oMMfCiRj7cnFbblx6aEQKtizryWe7CM=",
      "url": "fonts/Peyda/03- Non English/WebFonts/Peyda.html"
    },
    {
      "hash": "sha256-IKakNJoJdN2k2LCYjzVMkydg5YV5ecfPjMILL/wjLM8=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fontiran.css"
    },
    {
      "hash": "sha256-TtfQ3veROuqR6KvkLbI+bFgvj/9uTI4+TuVFavGjRqc=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-Black.woff"
    },
    {
      "hash": "sha256-+pKHZUa62372qqsaxeiU32SplBblivIzLCZvbY5Mr3w=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-Bold.woff"
    },
    {
      "hash": "sha256-hVjYxo3UPtTcyMot5lRgmbeQmsmsTvUqs/a314ibbNc=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-ExtraBold.woff"
    },
    {
      "hash": "sha256-2B5kdr7V306v7T5KZud0U+zLJMu4p1yl4MeTXcAE2Rw=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-ExtraLight.woff"
    },
    {
      "hash": "sha256-TLIbe+7sDO/Rseihas0nIiqtjY6qEzLAKE1+QyBjeWA=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-Light.woff"
    },
    {
      "hash": "sha256-Quua1pQ0U8Qqnu6yK2wfe832FKd0S9seA5e2HV8hBGU=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-Medium.woff"
    },
    {
      "hash": "sha256-UP8Rg58QjjNzuGAEqC+khO5knYOod4SyBJTWboxJbKg=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-Regular.woff"
    },
    {
      "hash": "sha256-jirNhhht5X7iEjlYRyybpRCFyFSJGTjW9/Hhkz/aNLU=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-SemiBold.woff"
    },
    {
      "hash": "sha256-9G762Jg0ig68WYc3Z7vzpzQU6TmLQei6pnuMQqrQ2Rg=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff/PeydaWebNoEn-Thin.woff"
    },
    {
      "hash": "sha256-oPAFJ85ATx6A8oLXKiiPcpqr/EG9ChaPRm259z5q7Sc=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-Black.woff2"
    },
    {
      "hash": "sha256-FplX1k2A/7NNaQH5oLFbzeaQOSu4TRBc+BUjwxYBqwU=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-Bold.woff2"
    },
    {
      "hash": "sha256-a63GM37hzpKdn5ysTlaZP0p7GExyGGnPaYWFtcK02Fo=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-ExtraBold.woff2"
    },
    {
      "hash": "sha256-e+lguHUYlRqIN6XGmtoJtE++gq3155cG4BjTnEDREcM=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-ExtraLight.woff2"
    },
    {
      "hash": "sha256-z44qNj3aavTufKxm6vG+KFYiROlIqzuNZFcdtQ5mhZQ=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-Light.woff2"
    },
    {
      "hash": "sha256-nZmuD/8U9Iy5j4OJxrHQsVVnYtNLUJm8OYgTT7LDyBU=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-Medium.woff2"
    },
    {
      "hash": "sha256-XMqeYmBrXJZPmkc7Th3NvP2iicuUc+gR8KhNd9QYwDQ=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-Regular.woff2"
    },
    {
      "hash": "sha256-gljZWCfidacYdkr4j5xQKGWsnLaXbQhs18yCwlh9tjE=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-SemiBold.woff2"
    },
    {
      "hash": "sha256-12OVSOOpAgGlSpmcF0ud/+2lGZ9fozAc9IwKJJPosLQ=",
      "url": "fonts/Peyda/03- Non English/WebFonts/fonts/woff2/PeydaWebNoEn-Thin.woff2"
    },
    {
      "hash": "sha256-6N8aasWKaWC2bjUic7+83zPFmTviHKEpUROgD2Tj+sg=",
      "url": "fonts/Peyda/03- Non English/WebFonts/style.css"
    },
    {
      "hash": "sha256-QcGmZZVlTcfHTuLBl2nXm8AbONOVK7fl1U6vONARLgk=",
      "url": "fonts/Peyda/Peyda Features.pdf"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-VmatXryDw4r9dLqBGRNuvDLEdBDWloicMqwSDdSLjGA=",
      "url": "index.html"
    },
    {
      "hash": "sha256-HZJ3xePWakAJuqRoKNC92BUDUJUSUrqxbBLawszIJHQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
